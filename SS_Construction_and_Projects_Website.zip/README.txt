S&S CONSTRUCTION AND PROJECTS WEBSITE

Open index.html in a browser to view the website.

The quotation form opens the visitor's email program with a pre-filled enquiry addressed to:
ssconstructprojects@gmail.com

To publish the website, upload index.html to your web host.

Replace the project placeholders in the Projects section with your own project photos when ready.
